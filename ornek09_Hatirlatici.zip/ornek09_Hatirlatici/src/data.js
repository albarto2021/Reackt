const data = [
  {
    id: 1,
    isim: "Canan Dertli",
    yas: 29,
    resim:
      "https://res.cloudinary.com/diqqf3eq2/image/upload/v1595959131/person-2_ipcjws.jpg",
  },

  {
    id: 2,
    isim: "Pamela Basmaci",
    yas: 32,
    resim:
      "https://res.cloudinary.com/diqqf3eq2/image/upload/v1595959131/person-3_rxtqvi.jpg",
  },
  {
    id: 3,
    isim: "Abubakar Okachu",
    yas: 33,
    resim:
      "https://res.cloudinary.com/diqqf3eq2/image/upload/v1586883423/person-4_t9nxjt.jpg",
  },
  {
    id: 4,
    isim: "Semih Yilmaz",
    yas: 21,
    resim:
      "https://res.cloudinary.com/diqqf3eq2/image/upload/v1586883417/person-3_ipa0mj.jpg",
  },
  {
    id: 5,
    isim: "Pelin Su Gulec",
    yas: 29,
    resim:
      "https://res.cloudinary.com/diqqf3eq2/image/upload/v1586883334/person-1_rfzshl.jpg",
  },
];
export default data;
