import MyNav from "./components/MyNav";
import Home from "./components/Home";
import Kurslar from "./components/Kurslar";
function App() {
  return (
    <div className="App">
      <MyNav />
      <Home />
      <Kurslar />
    </div>
  );
}
export default App;
