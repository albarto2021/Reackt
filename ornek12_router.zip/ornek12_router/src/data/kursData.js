const data = [
  {
    id: 1,
    name: "REACT",
    text: "React Kursumuzda A'dan Z'ye herseyi ogrneceksiniz",
    img: "https://cdn.iconscout.com/icon/free/png-512/react-1-282599.png",
  },
  {
    id: 2,
    name: "VUE",
    text: "Vue Kursumuzda A'dan Z'ye herseyi ogrneceksiniz",
    img: "https://cdn.icon-icons.com/icons2/2415/PNG/512/vuejs_original_wordmark_logo_icon_146305.png",
  },
  {
    id: 3,
    name: "ANGULAR",
    text: "Angular Kursumuzda A'dan Z'ye herseyi ogrneceksiniz",
    img: "https://cdn.icon-icons.com/icons2/2107/PNG/512/file_type_angular_icon_130754.png",
  },
];

export default data;
